"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Serie = void 0;
class Serie {
    constructor(id, nombre, productora, temporadas, reseña, url, imagen) {
        this.id = id;
        this.nombre = nombre;
        this.productora = productora;
        this.temporadas = temporadas;
        this.reseña = reseña;
        this.url = url;
        this.imagen = imagen;
    }
}
exports.Serie = Serie;
